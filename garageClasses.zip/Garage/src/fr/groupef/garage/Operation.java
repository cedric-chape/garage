package fr.groupef.garage;

public enum Operation {
	VIDANGE,PNEU,FREINS,DISTRIBUTION,AMORTISSEURS
}
