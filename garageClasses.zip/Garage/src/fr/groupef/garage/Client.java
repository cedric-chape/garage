package fr.groupef.garage;

public class Client {
	private String nom;
	private String prenom;
	private int typeDeClient;
	private int fidelite;
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public int getTypeDeClient() {
		return typeDeClient;
	}
	public void setTypeDeClient(int typeDeClient) {
		this.typeDeClient = typeDeClient;
	}
	public int getFidelite() {
		return fidelite;
	}
	public void setFidelite(int fidelite) {
		this.fidelite = fidelite;
	}
	
	public void afficherTypeDeClient() {
		switch (typeDeClient) {
		case 0:
			System.out.println("PARTICULIER");
			break;
		default:
			System.out.println("PRO");
			break;
		}
	}
	
	public void afficherFidelite() {
		switch (fidelite) {
		case 0:
			System.out.println("CLASSIQUE");
			break;
		default:
			System.out.println("PREMIUM");
			break;
		}
	}
}
