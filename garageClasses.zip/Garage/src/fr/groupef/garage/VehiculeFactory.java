package fr.groupef.garage;



public abstract class VehiculeFactory {
	
	public static Vehicule creerVehicule(String type) {
		type = type.toLowerCase();
		
		switch (type) {
		case "voiture" : return new Voiture();
		case "moto" : return new Moto();
		case "camion" : return new Camion();
		default : return null;
		}
	}


}
