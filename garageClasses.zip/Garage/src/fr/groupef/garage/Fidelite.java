package fr.groupef.garage;

public enum Fidelite {
	CLASSIQUE, PREMIUM
}
