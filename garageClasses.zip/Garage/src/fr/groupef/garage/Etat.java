package fr.groupef.garage;

public enum Etat {
		ENCOURS, TERMINEE, PASCOMMENCEE ;
}
