package fr.groupef.garage;

public class Moto extends Vehicule{

	public Moto() {
		System.out.println("CREATION D'UNE MOTO");
	}
}
