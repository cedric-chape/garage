package fr.groupef.garage;

public abstract class Vehicule {
	
	// Attributs
	private String nom;
	private String marque;
	private Client client;

	// Getters et Setters
	public String getNom() {
	return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public String getMarque() {
		return marque;
	}
	
	public void setMarque(String marque) {
		this.marque = marque;
	}
	
	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}
	
	// Constructeurs
	public Vehicule() {
		System.out.println("CREATION D'UN VEHICULE");
	}
	
	//M�thodes
	
	
}
