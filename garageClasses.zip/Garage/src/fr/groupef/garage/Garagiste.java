package fr.groupef.garage;

public class Garagiste {
	private String nom;
	private String prenom;
	private int operation;
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	static void Accueillir() {
		System.out.println("Le garagiste accueille le client");
	} 
	
	static void Examiner() {
		System.out.println("Le garagiste examine la voiture");
	}
	
	static void R�parer() {
		System.out.println("Le garagiste r�pare la voiture");
	}
	
	public void afficherPanneOuEntretien() {
		switch (operation) {
		case 0:
			System.out.println("VIDANGE");
			break;
		case 1:
			System.out.println("PNEUS");
			break;
		case 2:
			System.out.println("FREINS");
			break;
		case 3:
			System.out.println("DISTRIBUTION");
			break;
		case 4:
			System.out.println("AMORTISSEUR");
		}
	}
}
