package fr.groupef.garage;

public class Voiture extends Vehicule {
	
	// Constructeurs
	public Voiture() {
		System.out.println("CREATION D'UNE VOITURE");
	}

}
