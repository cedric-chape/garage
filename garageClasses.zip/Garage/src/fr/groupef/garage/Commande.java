package fr.groupef.garage;

public class Commande {
	
	private int numero ; 
	private Garagiste garagiste ; 
	private Client client ; 
	private Vehicule Vehicul ; 
	private Etat etat ; 
	
	
	public Commande() {		
		System.out.println("CREATION D'une Commande" );
		this.changerEtat(Etat.PASCOMMENCEE);	
	}	
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public Garagiste getGaragiste() {
		return garagiste;
	}
	public void setGaragiste(Garagiste garagiste) {
		this.garagiste = garagiste;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Vehicule getVehicul() {
		return Vehicul;
	}
	public void setVehicul(Vehicule vehicul) {
		Vehicul = vehicul;
	}
	public Etat getEtat() {
		return etat;
	}
	public void changerEtat(Etat etat) {
		this.etat = etat;
	}
	
	
	
	
	
	
	

}
