package fr.groupef.garage;

public enum TypeDeClient {
	PARTICULIER, PRO
}
