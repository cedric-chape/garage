package fr.groupef.garage;

public class Camion extends Vehicule {
	
	// Constructeur
	public Camion() {
		System.out.println("CREATION D'UN CAMION");
	}

}
