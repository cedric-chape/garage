package fr.groupef;

import fr.groupef.garage.Moto;
import fr.groupef.garage.Vehicule;
import fr.groupef.garage.VehiculeFactory;
import fr.groupef.garage.Voiture;

public class ApplicationGarage {

	public static void main(String[] args) {
		Vehicule voiture = VehiculeFactory.creerVehicule("voiture");
		Vehicule moto = VehiculeFactory.creerVehicule("Moto");
		Vehicule camion = VehiculeFactory.creerVehicule("CAMION");
	}

}
